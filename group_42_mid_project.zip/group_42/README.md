# group_42
Mid coding project for unipd

___

## Team:
* Elia Mirafiori 2008772
* Davide Iannello 2009661
* Alberto Celadin 2007950

## Date
22 Nov 2022

## Version
1.0.0

___

## CMake Instructions
1. open root folder [group_42_project/]
2. run `cd build` [group_42_project/build/]
3. run `cmake ..`
4. run `cmake --build .`

Now the program should be ready.

To run the program run `./main ` into the build folder.