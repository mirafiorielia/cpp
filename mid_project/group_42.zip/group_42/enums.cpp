
/*
#authors group_42:
@Elia Mirafiori 2008772
@Davide Iannello 2009661
@Alberto Celadin xxx

#date: 21 Nov 2022

#version: 1.0.0
*/

// month 0..11
enum Month {
    january = 0,
    february,
    march,
    april,
    may,
    june,
    july,
    august,
    september,
    octber,
    november,
    december
};