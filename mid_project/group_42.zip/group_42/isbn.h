#include <iostream>
#include <string>

using namespace std;

class isbn {
private:
    /* data */
public:
    isbn(/* args */);
    ~isbn();
};

isbn::isbn(/* args */)
{
}

isbn::~isbn()
{
}
